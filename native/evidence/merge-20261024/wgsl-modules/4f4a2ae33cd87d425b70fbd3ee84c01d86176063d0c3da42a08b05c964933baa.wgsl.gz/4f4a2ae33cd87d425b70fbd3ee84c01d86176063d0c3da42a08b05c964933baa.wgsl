// SPDX-FileCopyrightText: 2011-2022 Blender Foundation
// SPDX-FileCopyrightText: 2009-2010 Sony Pictures Imageworks Inc., et al. All Rights Reserved.
// SPDX-FileCopyrightText: 2009-2012 Intel Corporation
// Copyright (c) 2026 Jeremy Ellis and contributors
// SPDX-License-Identifier: Apache-2.0 AND BSD-3-Clause
// Modified from Cycles: selected surface integration, BSDF mixtures, native
// path-state updates and film writes in WGSL. See native/THIRD-PARTY-NOTICES.txt.
//#if SVM_BSDF_PRINCIPLED else fn surf_diffuse(kind:u32)->bool{return kind==CLOSURE_BSDF_DIFFUSE_ID||kind==CLOSURE_BSDF_OREN_NAYAR_ID||kind==CLOSURE_BSDF_TRANSLUCENT_ID;}
// CLOSURE_IS_BSDF_DIFFUSE also covers the Principled sheen closure.
fn surf_diffuse(kind:u32)->bool{return kind==CLOSURE_BSDF_DIFFUSE_ID||kind==CLOSURE_BSDF_OREN_NAYAR_ID||kind==CLOSURE_BSDF_TRANSLUCENT_ID||kind==CLOSURE_BSDF_SHEEN_ID;}
//#endif
fn surf_glossy(kind:u32)->bool{return kind==CLOSURE_BSDF_MICROFACET_GGX_ID;}
fn surf_glass(kind:u32)->bool{return kind==CLOSURE_BSDF_MICROFACET_GGX_GLASS_ID;}
//#if SVM_BSDF_THIN_WALL else fn surf_refraction(kind:u32)->bool{return kind==CLOSURE_BSDF_MICROFACET_GGX_REFRACTION_ID;}
// CLOSURE_IS_BSDF_TRANSMISSION also covers the thin-walled Principled transmission lobe.
fn surf_refraction(kind:u32)->bool{return kind==CLOSURE_BSDF_MICROFACET_GGX_REFRACTION_ID||kind==CLOSURE_BSDF_THIN_GLASS_TRANSMISSION_ID;}
//#endif
fn surf_microfacet(kind:u32)->bool{return surf_glossy(kind)||surf_glass(kind)||surf_refraction(kind);}
fn surf_glossy_direction(c:SvmClosure,wo:vec3<f32>)->bool{return surf_glossy(c.kind)||(surf_glass(c.kind)&&dot(c.N,wo)>0.0);}
fn surf_bsdf(kind:u32)->bool{return surf_diffuse(kind)||surf_microfacet(kind)||kind==CLOSURE_BSDF_TRANSPARENT_ID;}
fn surf_roughness(c:SvmClosure)->f32{if(surf_microfacet(c.kind)){return c.alpha_x*c.alpha_y;}return select(1.0,0.0,c.kind==CLOSURE_BSDF_TRANSPARENT_ID);}
fn surf_bump(sd:SurfaceData,c:SvmClosure,wo:vec3<f32>,is_eval:bool)->f32{
    if(all(c.N==sd.N)){return 1.0;}
    let ns_i=dot(sd.N,wo);let ns_n=dot(sd.N,c.N);let n_i=dot(c.N,wo);let diffuse=surf_diffuse(c.kind);
    if(ns_i*ns_n*n_i<0.0&&(is_eval||diffuse)){return 0.0;}
    if(!diffuse||(sd.shader_flag&SD_USE_BUMP_MAP_CORRECTION)==0u){return 1.0;}
    let ci=abs(ns_i);let cd=abs(ns_n);if(cd>=1.0||ci>=1.0){return 1.0;}if(ci<1e-6){return 0.0;}
    let alpha=clamp(0.125*(1.0/(cd*cd)-1.0),0.0,1.0);
    return 2.0/(1.0+sqrt(1.0+alpha*(1.0/(ci*ci)-1.0)));
}
fn surf_oren(c:SvmClosure,wi:vec3<f32>,wo:vec3<f32>)->vec3<f32>{
    let nl=max(dot(c.N,wo),0.0);if(c.b<=0.0){return vec3<f32>(nl*INV_PI);}
    let nv=max(dot(c.N,wi),0.0);var t=dot(wo,wi)-nl*nv;if(t>0.0){t/=max(nl,nv)+1.1754943508222875e-38;}
    let el=svm_oren_add(c.a*PI,c.b*svm_oren_g(nl));return nl*(vec3<f32>(c.a+c.b*t)+c.multiscatter*(1.0-el));
}
// Shadow terminator shading offset (bsdf.h): eval *= shift_cos_in(dot(wo, N))
// after the bump term when the object's frequency multiplier exceeds 1. Sample
// evaluation applies it to every reflection; evaluation only for cosNO >= 0.
fn surf_terminator(sd:SurfaceData,c:SvmClosure,wo:vec3<f32>,value:vec3<f32>,is_eval:bool)->vec3<f32>{
    let frequency=terminator_frequency(sd);if(frequency<=1.0){return value;}
//#if SHADOW_TERMINATOR_SHADING else atomicOr(&heap[p(17u)/4u],2u);return value;
    let cosNO=rounded_dot(wo,c.N);if(is_eval&&cosNO<0.0){return value;}
    return value*terminator_shift_cos_in(cosNO,frequency);
//#endif
}
fn surf_evaluate(sd:SurfaceData,c:SvmClosure,wo:vec3<f32>)->vec4<f32>{
    let e=surf_evaluate_closure(sd,c,wo);return vec4<f32>(surf_terminator(sd,c,wo,e.xyz,true),e.w);
}
fn surf_evaluate_closure(sd:SurfaceData,c:SvmClosure,wo:vec3<f32>)->vec4<f32>{
    let bump=surf_bump(sd,c,wo,true);if(bump==0.0||c.kind==CLOSURE_BSDF_TRANSPARENT_ID){return vec4<f32>(0);}
    if(surf_microfacet(c.kind)){
//#if SVM_BSDF_MICROFACET else atomicOr(&heap[p(17u)/4u],2u);return vec4<f32>(0);
//#if SVM_BSDF_THIN_WALL else         let value=ggx_evaluate(c,sd.wi,wo);return vec4<f32>(value.xyz*bump,value.w);
        // bsdf_thin_glass_transmission_eval: GGX reflection of the mirrored incoming direction.
        var g=c;var wi=sd.wi;if(c.kind==CLOSURE_BSDF_THIN_GLASS_TRANSMISSION_ID){g.kind=CLOSURE_BSDF_MICROFACET_GGX_ID;wi=rounded_add3(sd.wi,-((2.0*c.N)*rounded_dot(sd.wi,c.N)));}
        let value=ggx_evaluate(g,wi,wo);return vec4<f32>(value.xyz*bump,value.w);
//#endif
//#endif
    }
//#if SVM_BSDF_PRINCIPLED
    if(c.kind==CLOSURE_BSDF_SHEEN_ID){let value=sheen_evaluate(c,wo);return vec4<f32>(vec3<f32>(value*bump),value);}
//#endif
    let cosine=select(dot(c.N,wo),-dot(c.N,wo),c.kind==CLOSURE_BSDF_TRANSLUCENT_ID);let pdf=max(cosine,0.0)*INV_PI;
    if(c.kind==CLOSURE_BSDF_OREN_NAYAR_ID){if(cosine>0.0){return vec4<f32>(surf_oren(c,sd.wi,wo)*bump,pdf);}return vec4<f32>(0);}
    return vec4<f32>(vec3<f32>(pdf*bump),pdf);
}
struct SurfaceSample {wo:vec3<f32>,pdf:f32,eval:vec3<f32>,label:u32,diffuse:vec3<f32>,glossy:vec3<f32>,roughness:f32}
fn surf_sample(sd:SurfaceData,r:SvmResult,random:vec3<f32>)->SurfaceSample{
    var out:SurfaceSample;if((r.runtime_flag&SR_BSDF)==0u||r.count==0u){return out;}
    var selected=0u;var rand=random;
    if(r.count>1u){var sum=0.0;for(var i=0u;i<r.count;i++){let c=svm_closure_read(r,i);if(surf_bsdf(c.kind)){sum+=c.sample_weight;}}
        let pick=random.z*sum;var partial=0.0;for(var i=0u;i<r.count;i++){let c=svm_closure_read(r,i);if(surf_bsdf(c.kind)){
            let next=partial+c.sample_weight;if(pick<next){selected=i;rand.z=(pick-partial)/c.sample_weight;break;}partial=next;}}}
    let c=svm_closure_read(r,selected);if(!surf_bsdf(c.kind)){return out;}
    var value=vec3<f32>(0);
    if(c.kind==CLOSURE_BSDF_TRANSPARENT_ID){out.wo=-sd.wi;out.pdf=1e6;value=vec3<f32>(1e6);out.label=LABEL_TRANSMIT|LABEL_TRANSPARENT;
        if(data_float(D_background_transparent_roughness_squared_threshold)>=0.0){out.label|=LABEL_TRANSMIT_TRANSPARENT;}}
    else if(surf_microfacet(c.kind)){
//#if SVM_BSDF_MICROFACET else atomicOr(&heap[p(17u)/4u],2u);return out;
//#if SVM_BSDF_THIN_WALL else         out=ggx_sample(sd,c,rand);value=out.eval;
        // bsdf_thin_glass_transmission_sample: singular pass-through, or GGX on the
        // mirrored direction against the flipped geometric normal.
        let thin=c.kind==CLOSURE_BSDF_THIN_GLASS_TRANSMISSION_ID;var g=c;var gs=sd;
        if(thin){g.kind=CLOSURE_BSDF_MICROFACET_GGX_ID;gs.Ng=-sd.Ng;gs.wi=rounded_add3(sd.wi,-((2.0*c.N)*rounded_dot(sd.wi,c.N)));}
        if(thin&&c.alpha_x*c.alpha_y<=2e-10){out.wo=-sd.wi;out.pdf=1e6;out.eval=vec3<f32>(1e6);out.label=LABEL_TRANSMIT|LABEL_SINGULAR;}
        else{out=ggx_sample(gs,g,rand);if(thin&&out.label!=0u){out.label=LABEL_TRANSMIT|LABEL_GLOSSY;}}
        value=out.eval;
//#endif
        if((out.label&LABEL_TRANSMIT)!=0u){let threshold=data_float(D_background_transparent_roughness_squared_threshold);
            if(threshold>=0.0&&c.alpha_x*c.alpha_y<=threshold){out.label|=LABEL_TRANSMIT_TRANSPARENT;}}
        else{value=surf_terminator(sd,c,out.wo,value,false);value*=surf_bump(sd,c,out.wo,false);}
//#endif
    }
//#if SVM_BSDF_PRINCIPLED
    else if(c.kind==CLOSURE_BSDF_SHEEN_ID){out=sheen_sample(sd,c,rand.xy);value=surf_terminator(sd,c,out.wo,out.eval,false);value*=surf_bump(sd,c,out.wo,false);}
//#endif
    else{
        let transmission=c.kind==CLOSURE_BSDF_TRANSLUCENT_ID;let sampled=surface_cos_hemisphere(select(c.N,-c.N,transmission),random.xy);
        out.wo=sampled.xyz;out.pdf=sampled.w;out.label=LABEL_DIFFUSE|select(LABEL_REFLECT,LABEL_TRANSMIT,transmission);
        let valid=select(dot(sd.Ng,out.wo)>0.0,dot(sd.Ng,out.wo)<0.0,transmission);
        if(valid){value=vec3<f32>(out.pdf);if(c.kind==CLOSURE_BSDF_OREN_NAYAR_ID){value=surf_oren(c,sd.wi,out.wo);}
            if(!transmission){value=surf_terminator(sd,c,out.wo,value,false);value*=surf_bump(sd,c,out.wo,false);}}
        else{out.pdf=0.0;}
    }
    if(out.pdf==0.0){return out;}
    out.eval=value*c.weight;if(surf_diffuse(c.kind)){out.diffuse=out.eval;}
    if(surf_glossy_direction(c,out.wo)){out.glossy=out.eval;}
    out.roughness=surf_roughness(c);
    if(r.count>1u){var pdf_sum=out.pdf*c.sample_weight;var weight_sum=c.sample_weight;var rough_sum=pdf_sum*out.roughness;
        for(var i=0u;i<r.count;i++){if(i==selected){continue;}let other=svm_closure_read(r,i);if(!surf_bsdf(other.kind)){continue;}
            let e=surf_evaluate(sd,other,out.wo);if(e.w!=0.0){out.eval+=e.xyz*other.weight;if(surf_diffuse(other.kind)){out.diffuse+=e.xyz*other.weight;}if(surf_glossy_direction(other,out.wo)){out.glossy+=e.xyz*other.weight;}
                let w=e.w*other.sample_weight;pdf_sum+=w;rough_sum+=w*surf_roughness(other);}weight_sum+=other.sample_weight;}
        out.roughness=select(0.0,rough_sum/pdf_sum,pdf_sum>0.0);out.pdf=select(0.0,pdf_sum/weight_sum,weight_sum>0.0);
    }
    return out;
}
fn surf_prepare(index:u32,r:ptr<function,SvmResult>){
    let closure_filter=data_word(D_integrator_filter_closures);if((closure_filter&FILTER_CLOSURE_EMISSION)!=0u){(*r).emission=vec3<f32>(0);}
    if((state_byte(S_path_visibility,index)&VIS_CAMERA)==0u){return;}
    if((closure_filter&FILTER_CLOSURE_DIRECT_LIGHT)!=0u){(*r).runtime_flag&=~SR_BSDF_HAS_EVAL;}
    for(var i=0u;i<(*r).count;i++){var c=svm_closure_read(*r,i);
        if((surf_diffuse(c.kind)&&(closure_filter&FILTER_CLOSURE_DIFFUSE)!=0u)||(surf_glossy(c.kind)&&(closure_filter&FILTER_CLOSURE_GLOSSY)!=0u)||
           (surf_refraction(c.kind)&&(closure_filter&FILTER_CLOSURE_TRANSMISSION)!=0u)||
           (surf_glass(c.kind)&&(closure_filter&(FILTER_CLOSURE_GLOSSY|FILTER_CLOSURE_TRANSMISSION))==(FILTER_CLOSURE_GLOSSY|FILTER_CLOSURE_TRANSMISSION))){
            c.kind=CLOSURE_NONE_ID;c.sample_weight=0.0;}
        else if(c.kind==CLOSURE_BSDF_TRANSPARENT_ID&&(closure_filter&FILTER_CLOSURE_TRANSPARENT)!=0u){c.kind=CLOSURE_HOLDOUT_ID;c.sample_weight=0.0;(*r).runtime_flag|=SR_HOLDOUT;}
        svm_closure_write((*r).closure_base+i*SVM_CLOSURE_BYTES,c);
    }
}
fn surf_holdout(sd:SurfaceData,r:ptr<function,SvmResult>)->vec3<f32>{
    var weight=vec3<f32>(0);
    if((sd.object_flag&SD_OBJECT_HOLDOUT_MASK)!=0u){
        if(((*r).runtime_flag&SR_TRANSPARENT)!=0u){weight=vec3<f32>(1)-(*r).transparency;
            for(var i=0u;i<(*r).count;i++){var c=svm_closure_read(*r,i);if(c.kind!=CLOSURE_BSDF_TRANSPARENT_ID){c.kind=NBUILTIN_CLOSURES;svm_closure_write((*r).closure_base+i*SVM_CLOSURE_BYTES,c);}}
            (*r).runtime_flag&=SR_TRANSPARENT|SR_BSDF;
        }else{weight=vec3<f32>(1);}
    }else{for(var i=0u;i<(*r).count;i++){let c=svm_closure_read(*r,i);if(c.kind==CLOSURE_HOLDOUT_ID){weight+=c.weight;}}}
    return weight;
}
fn surf_ray_offset(sd:SurfaceData,direction:vec3<f32>)->vec3<f32>{return surf_ray_offset_at(sd,sd.P,direction);}
// integrate_surface_ray_offset for a ray starting at P (the hit point, or the
// shadow-terminator-offset origin).
fn surf_ray_offset_at(sd:SurfaceData,P:vec3<f32>,direction:vec3<f32>)->vec3<f32>{
    var pos=P;var dir=direction;if((sd.object_flag&SD_OBJECT_TRANSFORM_APPLIED)==0u){pos=surface_object_point(sd,pos,true);dir=surface_object_direction(sd,dir,true);}
    let vertices=native_triangle_vertices(sd.object_id,sd.prim,sd.primitive_type,sd.time);
    let a=vertices.a-pos;let b=vertices.b-pos;let c=vertices.c-pos;
    let u=c_ray_triangle_dot(c_ray_triangle_cross(c+a,c-a),dir);let v=c_ray_triangle_dot(c_ray_triangle_cross(a+b,a-b),dir);let w=c_ray_triangle_dot(c_ray_triangle_cross(b+c,b-c),dir);
    let eps=1.1920928955078125e-7*abs(u+v+w);if(min(u,min(v,w))>=eps||max(u,max(v,w))<=-eps){return P;}
    let amount=vec3<i32>(256.0*sd.Ng);let bits=bitcast<vec3<i32>>(P)+select(amount,-amount,P<vec3<f32>(0));
    return select(bitcast<vec3<f32>>(bits),P+(1.0/65536.0)*sd.Ng,abs(P)<vec3<f32>(1.0/32.0));
}
fn surf_next(index:u32,label:u32,runtime:u32){
    var flag=state_word(S_path_flag,index);let offset=state_half(S_path_rng_offset,index)+RNG_BOUNCE;state_u16(S_path_rng_offset,index,offset);
    if((label&LABEL_TRANSPARENT)!=0u){let n=state_half(S_path_transparent_bounce,index)+1u;flag|=PATH_RAY_TRANSPARENT;
        if(n>=data_word(D_integrator_transparent_max_bounce)){flag|=PATH_RAY_TERMINATE_ON_NEXT_SURFACE;}
        state_u16(S_path_transparent_bounce,index,n);state_u32(S_path_flag,index,flag);return;}
    let bounce=state_half(S_path_bounce,index)+1u;if(bounce>=data_word(D_integrator_max_bounce)){flag|=PATH_RAY_TERMINATE_AFTER_TRANSPARENT;}
    flag&=~(PATH_RAY_REFLECT|PATH_RAY_SINGULAR|PATH_RAY_TRANSPARENT|PATH_RAY_IMPORTANCE_BAKE|PATH_RAY_MIS_SKIP|PATH_RAY_MIS_HAD_TRANSMISSION);
    var visibility=0u;
    if((label&LABEL_DIFFUSE)!=0u){visibility=PATH_RAY_VISIBILITY_DIFFUSE;flag|=PATH_RAY_DIFFUSE_ANCESTOR;}
    else{visibility=PATH_RAY_VISIBILITY_GLOSSY;if((label&LABEL_SINGULAR)!=0u){flag|=PATH_RAY_SINGULAR|PATH_RAY_MIS_SKIP;}}
    if((label&LABEL_REFLECT)!=0u){flag|=PATH_RAY_REFLECT;flag&=~PATH_RAY_TRANSPARENT_BACKGROUND;
        if((label&LABEL_DIFFUSE)!=0u){let n=state_half(S_path_diffuse_bounce,index)+1u;state_u16(S_path_diffuse_bounce,index,n);if(n>=data_word(D_integrator_max_diffuse_bounce)){flag|=PATH_RAY_TERMINATE_AFTER_TRANSPARENT;}}
        else{let n=state_half(S_path_glossy_bounce,index)+1u;state_u16(S_path_glossy_bounce,index,n);if(n>=data_word(D_integrator_max_glossy_bounce)){flag|=PATH_RAY_TERMINATE_AFTER_TRANSPARENT;}}}
    else{visibility|=PATH_RAY_VISIBILITY_TRANSMIT;if((label&LABEL_TRANSMIT_TRANSPARENT)==0u){flag&=~PATH_RAY_TRANSPARENT_BACKGROUND;}
        let n=state_half(S_path_transmission_bounce,index)+1u;state_u16(S_path_transmission_bounce,index,n);if(n>=data_word(D_integrator_max_transmission_bounce)){flag|=PATH_RAY_TERMINATE_AFTER_TRANSPARENT;}}
    if((runtime&SR_BSDF_HAS_TRANSMISSION)!=0u){flag|=PATH_RAY_MIS_HAD_TRANSMISSION;}
    if((flag&PATH_RAY_ANY_PASS)==0u&&(flag&PATH_RAY_TRANSPARENT_BACKGROUND)==0u){flag|=PATH_RAY_SURFACE_PASS;}
    state_u8(S_path_visibility,index,visibility);state_u32(S_path_flag,index,flag);state_u16(S_path_bounce,index,bounce);
}
// The queue this dispatch serves: push word 29 names SHADE_SURFACE_RAYTRACE
// (shaders with the AO node, wavefront_ao.wgsl); 0 is SHADE_SURFACE.
fn surf_queue()->u32{
//#if SVM_NODE_AO else return DEVICE_KERNEL_INTEGRATOR_SHADE_SURFACE;
    return select(DEVICE_KERNEL_INTEGRATOR_SHADE_SURFACE,p(29u),p(29u)!=0u);
//#endif
}
fn surf_finish(index:u32,continues:bool){
    let counter=load_word(p(7u)+S_queue_counter);atomicSub(&heap[counter/4u+surf_queue()],1u);
    if(continues){atomicAdd(&heap[counter/4u+K_CLOSEST],1u);state_u16(S_path_queued_kernel,index,K_CLOSEST);}else{volume_write_depth(index);state_u16(S_path_queued_kernel,index,0u);}
}
fn surf_emission(index:u32,base:u32,sd:SurfaceData,emission:vec3<f32>,mis_weight:f32){
    let throughput=heap_vec3(state_address(S_path_throughput,index,12u));var value=throughput*emission*mis_weight;
    value=select(value,vec3<f32>(0),(bitcast<vec3<u32>>(value)&vec3<u32>(0x7f800000u))==vec3<u32>(0x7f800000u));
    let bounce=state_half(S_path_bounce,index);let limit=select(data_float(D_integrator_sample_clamp_direct),data_float(D_integrator_sample_clamp_indirect),i32(bounce)-1>0);
    let total=abs(value.x)+abs(value.y)+abs(value.z);if(total>limit){value*=limit/total;}
    volume_guidance_pass(index,base,value);
//#if SHADOW_CATCHER else     let flags=data_word(D_film_light_pass_flag);if((flags&MASK_COMBINED)!=0u){film_rgb(base,data_word(D_film_pass_combined),value);}
    let flags=data_word(D_film_light_pass_flag);let sc_handled=sc_combined(state_word(S_path_flag,index),base,value);if(!sc_handled&&(flags&MASK_COMBINED)!=0u){film_rgb(base,data_word(D_film_pass_combined),value);}
//#endif
//#if SHADOW_CATCHER else     if(data_word(D_film_pass_adaptive_aux_buffer)!=PASS_NONE&&(countOneBits(state_word(S_path_sample,index)&0xaaaaaaaau)&1u)!=0u){film_rgb(base,data_word(D_film_pass_adaptive_aux_buffer),value*2.0);}
    if(!sc_handled&&data_word(D_film_pass_adaptive_aux_buffer)!=PASS_NONE&&(countOneBits(state_word(S_path_sample,index)&0xaaaaaaaau)&1u)!=0u){film_rgb(base,data_word(D_film_pass_adaptive_aux_buffer),value*2.0);}
//#endif
    if(flags==0u){return;}let flag=state_word(S_path_flag,index);let group=load_word(table_at(G_objects,sd.object_id,SIZE_objects)+O_lightgroup);
//#if SHADOW_CATCHER else     if(group!=NONE&&data_word(D_film_pass_lightgroup)!=PASS_NONE){film_rgb(base,data_word(D_film_pass_lightgroup)+3u*group,value);}
    if(sc_light_passes(flag)&&group!=NONE&&data_word(D_film_pass_lightgroup)!=PASS_NONE){film_rgb(base,data_word(D_film_pass_lightgroup)+3u*group,value);}
//#endif
    if((flag&PATH_RAY_ANY_PASS)==0u){film_rgb(base,data_word(D_film_pass_emission),value);}
//#if SHADOW_CATCHER else     else if(p(20u)!=0u&&(flag&PATH_RAY_SURFACE_PASS)!=0u){let diffuse=heap_vec3(state_address(S_path_pass_diffuse_weight,index,12u));let glossy=heap_vec3(state_address(S_path_pass_glossy_weight,index,12u));
    else if(sc_light_passes(flag)&&p(20u)!=0u&&(flag&PATH_RAY_SURFACE_PASS)!=0u){let diffuse=heap_vec3(state_address(S_path_pass_diffuse_weight,index,12u));let glossy=heap_vec3(state_address(S_path_pass_glossy_weight,index,12u));
//#endif
        film_rgb(base,select(data_word(D_film_pass_glossy_indirect),data_word(D_film_pass_glossy_direct),bounce==1u),glossy*value);
        film_rgb(base,select(data_word(D_film_pass_transmission_indirect),data_word(D_film_pass_transmission_direct),bounce==1u),(vec3<f32>(1)-diffuse-glossy)*value);
        film_rgb(base,select(data_word(D_film_pass_diffuse_indirect),data_word(D_film_pass_diffuse_direct),bounce==1u),diffuse*value);}
}
//#if SHADOW_CATCHER
// film_write_data_passes with only the shadow catcher passes in the data pass
// flag (every other data pass is refused): no film write, only the
// PATH_RAY_SINGLE_PASS_DONE bookkeeping of the pinned function.
fn sc_data_passes(index:u32,r:SvmResult){
    let flag=state_word(S_path_flag,index);
    if((flag&SC_TRANSPARENT_BACKGROUND)==0u||(flag&SC_PATH_PASS)!=0u||data_word(SC_D_pass_flag)==0u||(flag&SC_SINGLE_PASS_DONE)!=0u){return;}
    let threshold=data_float(SC_D_pass_alpha_threshold);
    if((r.runtime_flag&(SC_SR_TRANSPARENT|SC_SR_RAY_PORTAL))!=0u&&threshold!=0.0){
        let alpha=clamp(vec3<f32>(1)-r.transparency,vec3<f32>(0),vec3<f32>(1));
        if(!((alpha.x+alpha.y+alpha.z)*(1.0/3.0)>=threshold)){return;}
    }
    state_u32(S_path_flag,index,flag|SC_SINGLE_PASS_DONE);
}
//#endif
// Preparation validates inputs and evaluates closures without changing path or film state.
@compute @workgroup_size(64) fn prepare_surface(@builtin(global_invocation_id) id:vec3<u32>){surface_prepare(id);}
fn surface_prepare(id:vec3<u32>){
    svm_invocation(id.x);
    if(id.x>=p(1u)){return;}store_word(p(24u)+id.x*SURFACE_STAGE_BYTES,0u);var index=id.x;if(p(2u)!=0u){index=load_word(p(2u)+id.x*4u);}
<<<<<<< ours(main)
    if(index>=p(10u)){fail();return;}if(state_half(S_path_queued_kernel,index)!=DEVICE_KERNEL_INTEGRATOR_SHADE_SURFACE){fail();return;}
//#if SHADOW_CATCHER else     let flag=state_word(S_path_flag,index);if((flag&SURFACE_UNSUPPORTED_FLAGS)!=0u){fail();return;}
    let flag=state_word(S_path_flag,index);if((flag&(SURFACE_UNSUPPORTED_FLAGS&~SC_FLAGS))!=0u){fail();return;}
//#endif
=======
    if(index>=p(10u)){fail();return;}if(state_half(S_path_queued_kernel,index)!=surf_queue()){fail();return;}
    let flag=state_word(S_path_flag,index);if((flag&SURFACE_UNSUPPORTED_FLAGS)!=0u){fail();return;}
>>>>>>> theirs(m2-ao)
    let stride=data_word(D_film_pass_stride);let pixel=state_word(S_path_render_pixel_index,index);if(pixel>=p(11u)/stride){fail();return;}let base=p(4u)+pixel*stride*4u;
    var sd=surface_cached(id.x);if(sd.error!=0u){return;}let object=table_at(G_objects,sd.object_id,SIZE_objects);
    let group=load_word(object+O_lightgroup);let go=data_word(D_film_pass_lightgroup);if(group!=NONE&&go!=PASS_NONE&&(group>=stride/3u||go>stride-3u*(group+1u))){fail();return;}
    if(volume_enabled()&&(sd.shader_flag&VS_HAS_VOLUME)!=0u){if(volume_stack_count(index)==NONE){return;}}
    if((sd.shader_flag&SD_HAS_ONLY_VOLUME)!=0u){var empty:SvmResult;surface_stage_write(p(24u)+id.x*SURFACE_STAGE_BYTES,sd,empty);return;}
    var r=svm_evaluate(index,sd,data_word(D_max_closures),p(23u)+id.x*SVM_CLOSURE_CAPACITY*SVM_CLOSURE_BYTES);if(r.error!=0u){return;}sd.N=r.N;surf_prepare(index,&r);
    surface_stage_write(p(24u)+id.x*SURFACE_STAGE_BYTES,sd,r);
}
// Direct lighting runs in two dispatches. shade_surface_light samples the lamp or
// emissive triangle and the forward-hit triangle MIS weight (state 1 -> 3);
// connect_surface_light applies holdout, emission, roulette and the sampled
// light's BSDF/MIS/shadow setup (state 3 -> 2). Combining emitter sampling with
// BSDF evaluation caused multi-minute, multi-GB driver compilation (and lost the
// Pixel's device); records remain GPU-private and native scheduling is unchanged.
//
// With emissive triangles in the scene (LIGHT_TRIANGLE) the sampling itself is
// split once more: shade_surface_light samples only a selected lamp (state
// 1 -> 5) and shade_surface_light_triangle, dispatched next, prefills the
// triangle vertices, computes the forward-hit MIS weight and samples a selected
// triangle (state 5 -> 3). Both recompute the same inputs from the unchanged
// stage record and path state, and call the same functions as the combined path,
// so the stored weight and sample are identical. One entry inlining both samplers
// with area lights and object motion passed 65,535 backend instructions, where
// the Intel Mesa 25.0.7 constant-combining pass truncates instruction and
// register numbers to 16 bits (crash or wrong code; native/DEVICE.md, "Linux
// reference fixes on the updated Mesa").
struct SurfaceLightInputs {at:u32,index:u32,sd:SurfaceData,r:SvmResult,emission:bool,sample:bool}
fn surface_light_inputs(id:vec3<u32>,state:u32)->SurfaceLightInputs{
    var li:SurfaceLightInputs;li.at=NONE;
    if(id.x>=p(1u)||(p(28u)!=0u&&load_word(p(17u))!=0u)){return li;}
    let at=p(24u)+id.x*SURFACE_STAGE_BYTES;if(load_word(at)!=state){return li;}store_word(at,0u);
//#if LIGHT_SELECT
    light_select_record=at;
//#endif
    var index=id.x;if(p(2u)!=0u){index=load_word(p(2u)+id.x*4u);}
    let stage=surface_stage_read(at);let sd=stage.sd;let r=stage.r;
    let flag=state_word(S_path_flag,index);let emission=(r.runtime_flag&SR_EMISSION)!=0u;
    let sample=data_word(D_integrator_use_direct_light)!=0u&&(r.runtime_flag&SR_BSDF_HAS_EVAL)!=0u&&
       (sd.shader_flag&SD_HAS_ONLY_VOLUME)==0u&&(flag&PATH_RAY_TERMINATE_ON_NEXT_SURFACE)==0u&&
       heap_float(state_address(S_path_continuation_probability,index,4u))!=0.0;
    return SurfaceLightInputs(at,index,sd,r,emission,sample);
}
//#if LIGHT_SELECT
// Light selection (lane m2-lighttree), dispatched before shade_surface_light when
// the scene uses the light tree or light linking. For a record in state 1 (left
// unchanged) it selects the emitter as light_sample_from_position does
// (light_tree_sample<false> or the flat CDF, then light_link_object_match on
// the object; a failed selection or a rejected link is no sample), and the
// tree's pdf of an emissive triangle hit for the forward MIS weight
// (light_sample_mis_weight_forward_surface). The samplers read the record.
struct LightSelectResult {selection:LightSelection,forward_pdf:f32}
// sample: the path samples a light here (shade_surface_light's condition);
// forward: the tree's pdf of this emissive-triangle hit is needed.
fn light_selection_compute(index:u32,sd:SurfaceData,r:SvmResult,sample:bool,forward:bool)->LightSelectResult{
    // prim -1: an invalid selection takes the lamp path, which returns no sample.
    var out=LightSelectResult(LightSelection(vec3<f32>(0),0u,-1,NONE,0u,0.0,false,false),0.0);
    let tree=data_word(LT_D_use_light_tree)!=0u;let flag=state_word(S_path_flag,index);
    if(sample&&!tree){out.selection=light_select(index);}
    // One traversal call site: k=0 samples (NEE), k=1 the forward triangle pdf.
    for(var k=0u;k<2u;k++){
        if((k==0u&&!(sample&&tree))||(k==1u&&!(forward&&tree))){continue;}
        var P=sd.P;var N=sd.N;var transmission=(r.runtime_flag&LT_SR_BSDF_HAS_TRANSMISSION)!=0u;var receiver=select(NONE,sd.object_id,light_link_enabled());var goal=0u;
        if(k==1u){
            if((state_byte(S_path_visibility,index)&LT_PATH_RAY_VISIBILITY_VOLUME_SCATTER)!=0u){fail();return out;}
            P=heap_vec3(state_address(S_ray_P,index,12u));N=heap_vec3(state_address(S_path_mis_origin_n,index,12u));
            transmission=(flag&LT_PATH_RAY_MIS_HAD_TRANSMISSION)!=0u;receiver=light_link_receiver_forward(index);
            let offset=load_word(table_at(G_object_lookup_offset,sd.object_id,4u));let first=load_word(table_at(G_object_prim_offset,sd.object_id,4u));
            goal=load_word(table_at(G_triangle_to_tree,sd.prim-first+offset,4u));
        }
        let random=native_rng(state_word(S_path_sample,index),state_word(S_path_rng_pixel,index),state_half(S_path_rng_offset,index)+PRNG_LIGHT).xyz;
        let walk=light_tree_walk(k==0u,P,N,transmission,receiver,random.z,sd.object_id,goal);
        if(k==1u){out.forward_pdf=walk.pdf;continue;}
        out.selection.random=random;
        if(walk.emitter>=0){let e=lt_emitter(u32(walk.emitter));out.selection.prim=bitcast<i32>(load_word(e+LTE_id));out.selection.visibility=load_word(e+LTE_visibility);
            out.selection.object=select(load_word(e+LTE_object),walk.object,out.selection.prim>=0);out.selection.pdf=walk.pdf;out.selection.tree=true;out.selection.valid=true;
            out.selection.distribution=u32(walk.emitter);}
    }
    if(out.selection.valid&&!light_link_match(sd.object_id,out.selection.object)){out.selection.valid=false;out.selection.prim= -1;}
    return out;
}
@compute @workgroup_size(1) fn shade_surface_light_select(@builtin(global_invocation_id) id:vec3<u32>){
    svm_invocation(id.x);
    if(id.x>=p(1u)||(p(28u)!=0u&&load_word(p(17u))!=0u)){return;}
    let at=p(24u)+id.x*SURFACE_STAGE_BYTES;if(load_word(at)!=1u){return;}
    var index=id.x;if(p(2u)!=0u){index=load_word(p(2u)+id.x*4u);}
    let stage=surface_stage_read(at);let sd=stage.sd;let r=stage.r;
    let flag=state_word(S_path_flag,index);
    let sample=data_word(D_integrator_use_direct_light)!=0u&&(r.runtime_flag&SR_BSDF_HAS_EVAL)!=0u&&
       (sd.shader_flag&SD_HAS_ONLY_VOLUME)==0u&&(flag&PATH_RAY_TERMINATE_ON_NEXT_SURFACE)==0u&&
       heap_float(state_address(S_path_continuation_probability,index,4u))!=0.0;
    let forward=(r.runtime_flag&SR_EMISSION)!=0u&&(flag&PATH_RAY_MIS_SKIP)==0u&&(sd.shader_flag&select(SD_MIS_FRONT,SD_MIS_BACK,(sd.runtime_flag&SR_BACKFACING)!=0u))!=0u;
    let result=light_selection_compute(index,sd,r,sample,forward);
    if(load_word(p(17u))!=0u){return;}
    light_selection_write(at,result.selection,result.forward_pdf);
}
//#endif
// The combined light stage (no emissive triangle in the scene).
fn surface_light_combined(li:SurfaceLightInputs){
    let index=li.index;let sd=li.sd;let r=li.r;let emission=li.emission;let sample=li.sample;let at=li.at;
    triangle_light_prefill(index,sd,emission,sample);
    var weight=1.0;if(emission){weight=triangle_light_forward_weight(index,sd);}
    var ls:NativeLightSample;
    if(sample){ls=light_sample_native(index,sd,r);}
    if(load_word(p(17u))!=0u){return;}
    store_word(at+304u,bitcast<u32>(weight));light_sample_write(at+308u,ls);store_word(at,3u);
}
@compute @workgroup_size(1) fn shade_surface_light(@builtin(global_invocation_id) id:vec3<u32>){
    svm_invocation(id.x);
    let li=surface_light_inputs(id,1u);if(li.at==NONE){return;}
//#if LIGHT_TRIANGLE else surface_light_combined(li);return;
    var ls:NativeLightSample;
    if(li.sample){let selection=light_select(li.index);if(selection.prim<0){ls=light_sample_lamp(li.index,li.sd,li.r,selection);}}
    if(load_word(p(17u))!=0u){return;}
    light_sample_write(li.at+308u,ls);store_word(li.at,5u);
//#endif
}
//#if LIGHT_TRIANGLE
@compute @workgroup_size(1) fn shade_surface_light_triangle(@builtin(global_invocation_id) id:vec3<u32>){
    svm_invocation(id.x);
    let li=surface_light_inputs(id,5u);if(li.at==NONE){return;}
    triangle_light_prefill(li.index,li.sd,li.emission,li.sample);
    var weight=1.0;if(li.emission){weight=triangle_light_forward_weight(li.index,li.sd);}
//#if SHADOW_CATCHER else     if(li.sample){let selection=light_select(li.index);if(selection.prim>=0){
    if(li.sample){let selection=light_select(li.index);if(selection.prim>=0&&!sc_triangle_excluded(li.index,selection)){
//#endif
        let ls=light_sample_triangle(li.sd,selection);if(load_word(p(17u))!=0u){return;}light_sample_write(li.at+308u,ls);}}
    if(load_word(p(17u))!=0u){return;}
    store_word(li.at+304u,bitcast<u32>(weight));store_word(li.at,3u);
}
//#endif
// Size 1 retains the verified Linux sampling layout; broader tuning remains open.
@compute @workgroup_size(1) fn connect_surface_light(@builtin(global_invocation_id) id:vec3<u32>){
    svm_invocation(id.x);
    if(id.x>=p(1u)||(p(28u)!=0u&&load_word(p(17u))!=0u)){return;}let at=p(24u)+id.x*SURFACE_STAGE_BYTES;if(load_word(at)!=3u){return;}store_word(at,0u);
    var index=id.x;if(p(2u)!=0u){index=load_word(p(2u)+id.x*4u);}
    let stage=surface_stage_read(at);var sd=stage.sd;var r=stage.r;
    let flag=state_word(S_path_flag,index);let stride=data_word(D_film_pass_stride);
    let pixel=state_word(S_path_render_pixel_index,index);let base=p(4u)+pixel*stride*4u;
    if(((r.runtime_flag&SR_HOLDOUT)!=0u||(sd.object_flag&SD_OBJECT_HOLDOUT_MASK)!=0u)&&(flag&PATH_RAY_TRANSPARENT_BACKGROUND)!=0u){
        let weight=surf_holdout(sd,&r);let contribution=weight*heap_vec3(state_address(S_path_throughput,index,12u));
        if((data_word(D_film_light_pass_flag)&MASK_COMBINED)!=0u){film_add(base+(data_word(D_film_pass_combined)+3u)*4u,(contribution.x+contribution.y+contribution.z)*(1.0/3.0));}
//#if SHADOW_CATCHER
        sc_transparent_only(flag,base,(contribution.x+contribution.y+contribution.z)*(1.0/3.0));
//#endif
        volume_transparent_pass(index,base,(contribution.x+contribution.y+contribution.z)*(1.0/3.0));
        if(all(weight==vec3<f32>(1))){surf_finish(index,false);return;}
    }
//#if LIGHT_LINKING else if((r.runtime_flag&SR_EMISSION)!=0u){surf_emission(index,base,sd,select(vec3<f32>(0),r.emission,abs(dot(sd.Ng,sd.wi))>0.0),heap_float(at+304u));}
    // integrate_surface_emission: an indirect ray sees only emitters linked to its receiver.
    if((r.runtime_flag&SR_EMISSION)!=0u&&light_link_forward_visible(index,sd.object_id)){surf_emission(index,base,sd,select(vec3<f32>(0),r.emission,abs(dot(sd.Ng,sd.wi))>0.0),heap_float(at+304u));}
//#endif
    let probability=select(heap_float(state_address(S_path_continuation_probability,index,4u)),0.0,(flag&PATH_RAY_TERMINATE_ON_NEXT_SURFACE)!=0u);
    if(probability==0.0){surf_finish(index,false);return;}
    var throughput=heap_vec3(state_address(S_path_throughput,index,12u));if(probability!=1.0){throughput/=probability;state_vec3(S_path_throughput,index,throughput);}
    if((sd.shader_flag&SD_HAS_ONLY_VOLUME)!=0u){
        let bounds=state_half(S_path_volume_bounds_bounce,index)+1u;state_u16(S_path_volume_bounds_bounce,index,bounds);
        if(bounds>VS_BOUNDS_MAX){surf_finish(index,false);return;}
        state_u16(S_path_rng_offset,index,state_half(S_path_rng_offset,index)+RNG_BOUNCE);
        let t=sd.ray_length;state_f32(S_ray_tmin,index,select(bitcast<f32>(bitcast<u32>(t)+1u),1.1754943508222875e-38,t==0.0));
        volume_stack_enter_exit(index,sd.object_id,sd.shader,(sd.runtime_flag&SR_BACKFACING)!=0u);surf_finish(index,true);return;
    }
//#if SHADOW_CATCHER
    sc_data_passes(index,r);
//#endif
    surface_direct_light(index,id.x,sd,r,light_sample_read(at+308u));if(load_word(p(17u))!=0u){return;}
//#if AO_SHADOW
    if((data_word(D_kernel_features)&(AO_FEATURE_ADDITIVE|AO_FEATURE_PASS))!=0u){surface_ao(index,id.x,sd,r);if(load_word(p(17u))!=0u){return;}}
//#endif
    // Holdout may change closure metadata; retain it with the same GPU record.
    surface_stage_write(at,sd,r);store_word(at,2u);
}
// Lighting and continuation share GPU records, with no native queue transition.
// The continuation runs only after successful lighting/roulette preparation.
@compute @workgroup_size(1) fn shade_surface(@builtin(global_invocation_id) id:vec3<u32>){
    svm_invocation(id.x);
    if(id.x>=p(1u)||(p(28u)!=0u&&load_word(p(17u))!=0u)){return;}let at=p(24u)+id.x*SURFACE_STAGE_BYTES;if(load_word(at)!=2u){return;}
    var index=id.x;if(p(2u)!=0u){index=load_word(p(2u)+id.x*4u);}
    let stage=surface_stage_read(at);let sd=stage.sd;let r=stage.r;
    let throughput=heap_vec3(state_address(S_path_throughput,index,12u));
    let random=native_rng(state_word(S_path_sample,index),state_word(S_path_rng_pixel,index),state_half(S_path_rng_offset,index)+PRNG_SURFACE_BSDF).xyz;
    let sampled=surf_sample(sd,r,random);if(sampled.pdf==0.0||all(sampled.eval==vec3<f32>(0))){surf_finish(index,false);return;}
    if((sampled.label&LABEL_TRANSPARENT)!=0u){let t=sd.ray_length;state_f32(S_ray_tmin,index,select(bitcast<f32>(bitcast<u32>(t)+1u),1.1754943508222875e-38,t==0.0));}
    else{let direction=surface_normalize(sampled.wo);state_vec3(S_ray_P,index,surf_ray_offset(sd,direction));state_vec3(S_ray_D,index,direction);
        state_f32(S_ray_tmin,index,0.0);state_f32(S_ray_tmax,index,3.4028234663852886e38);state_f32(S_ray_dP,index,sd.dP);
        let dd=heap_float(state_address(S_ray_dD,index,4u));state_f32(S_ray_dD,index,select(dd,max(dd,sqrt(sampled.roughness)),sampled.roughness>0.0));}
    state_vec3(S_path_throughput,index,throughput*(sampled.eval/sampled.pdf));
    if(p(20u)!=0u&&state_half(S_path_bounce,index)==0u){state_vec3(S_path_pass_diffuse_weight,index,svm_divide(sampled.diffuse,sampled.eval));state_vec3(S_path_pass_glossy_weight,index,svm_divide(sampled.glossy,sampled.eval));}
    if((sampled.label&LABEL_TRANSPARENT)==0u){state_f32(S_path_mis_ray_pdf,index,sampled.pdf);state_vec3(S_path_mis_origin_n,index,sd.N);
        state_f32(S_path_min_ray_pdf,index,min(sampled.pdf,heap_float(state_address(S_path_min_ray_pdf,index,4u))));
//#if LIGHT_LINKING
        if(light_link_enabled()){state_u32(S_path_mis_ray_object,index,sd.object_id);}
//#endif
    }
    surf_next(index,sampled.label,r.runtime_flag);
    if((sampled.label&LABEL_TRANSMIT)!=0u){volume_stack_enter_exit(index,sd.object_id,sd.shader,(sd.runtime_flag&SR_BACKFACING)!=0u);}
    surf_finish(index,true);
}
