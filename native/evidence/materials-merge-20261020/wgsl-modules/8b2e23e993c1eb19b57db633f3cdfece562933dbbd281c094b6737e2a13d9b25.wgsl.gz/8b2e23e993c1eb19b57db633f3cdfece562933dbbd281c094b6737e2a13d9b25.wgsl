//#if SVM_NODE_TEX_GABOR
// gabor.h: 2D and 3D Gabor noise (8 impulses per cell, 3x3 / 3x3x3 cell
// neighbourhoods, x fastest as the nested host loops), phasor value, phase and
// intensity. The 2D form runs as 3D with a zero third lane: every dot product,
// distance and frequency vector is then the host's 2D arithmetic plus exact
// zero terms. Seeds hash exact integer cell coordinates; the kernel window is
// zero at the unit-distance cutoff, so the sum is continuous there.
fn svm_gabor_texture(s:ptr<function,SvmState>,node:u32){
    let kind=load_word(node+N_TexGabor_gabor_type);if(kind>NODE_GABOR_TYPE_3D){svm_error(s,16u);return;}
    let coordinates=svm_load3(s,svm_byte(node+N_TexGabor_coordinates));let scale=svm_input(s,node+N_TexGabor_scale);
    let frequency=max(0.001,svm_input(s,node+N_TexGabor_frequency));let isotropy=1.0-clamp(svm_input(s,node+N_TexGabor_anisotropy),0.0,1.0);
    let orientation_2d=svm_input(s,node+N_TexGabor_orientation_2d);let orientation_3d=svm_input3(s,node+N_TexGabor_orientation_3d);
    if((*s).error!=0u){return;}
    let three=kind==NODE_GABOR_TYPE_3D;
    var scaled=coordinates*scale;if(!three){scaled.z=0.0;}
    let cell_position=floor(scaled);let local_position=scaled-cell_position;
    // compute_3d_orientation: spherical angles of the normalized base orientation.
    var base=vec3<f32>(0);var inclination=0.0;var azimuth=0.0;
    if(three){
        base=surface_native_normalize(orientation_3d);
        inclination=acos(base.z);azimuth=select(1.0,-1.0,base.y<0.0)*acos(base.x/sqrt(base.x*base.x+base.y*base.y));
    }
    var sum=vec2<f32>(0);
    for(var c=0u;c<select(9u,27u,three);c++){
        let offset=vec3<f32>(f32(i32(c%3u)-1),f32(i32((c/3u)%3u)-1),select(0.0,f32(i32(c/9u)-1),three));
        let cell=cell_position+offset;let position=local_position-offset;var noise=vec2<f32>(0);
        for(var i=0u;i<8u;i++){
            // Seeds: hash_float3_to_float(2) keys (cell.xy, 3i+k) in 2D,
            // hash_float4_to_float(2/3) keys (cell, 3i+k) in 3D.
            var key=vec4<f32>(cell.x,cell.y,f32(3u*i),0);var n=3u;if(three){key=vec4<f32>(cell,f32(3u*i));n=4u;}
            var frequency_vector=vec3<f32>(0);
            if(three){
                var orientation=base;
                if(isotropy!=0.0){
                    let angles=vec2<f32>(svmn_hash_float(key,4u),svmn_hash_float(key.zxwy,4u))*3.1415927;
                    let theta=inclination+angles.x*isotropy;let phi=azimuth+angles.y*isotropy;
                    orientation=vec3<f32>(sin(theta)*cos(phi),sin(theta)*sin(phi),cos(theta));
                }
                frequency_vector=frequency*orientation;
            }else{
                let orientation=orientation_2d+((svmn_hash_float(key,3u)-0.5)*3.1415927)*isotropy;
                frequency_vector=vec3<f32>(frequency*cos(orientation),frequency*sin(orientation),0);
            }
            let lane=select(vec4<f32>(0,0,1,0),vec4<f32>(0,0,0,1),three);let center_key=key+lane;
            var center=vec3<f32>(svmn_hash_float(center_key,n),0,0);
            if(three){center.y=svmn_hash_float(center_key.zxwy,4u);center.z=svmn_hash_float(center_key.wzyx,4u);}
            else{center.y=svmn_hash_float(center_key.zxyw,3u);}
            let p=position-center;let distance_squared=(p.x*p.x+p.y*p.y)+p.z*p.z;
            if(distance_squared>=1.0){continue;}
            let weight_key=key+2.0*lane;
            let weight=select(1.0,-1.0,svmn_hash_float(weight_key,n)<0.5);
            // compute_2d/3d_gabor_kernel: Hann-windowed Gaussian times the phasor.
            let envelope=exp(-3.1415927*distance_squared)*(0.5+0.5*cos(3.1415927*distance_squared));
            let angle=6.2831855*((p.x*frequency_vector.x+p.y*frequency_vector.y)+p.z*frequency_vector.z);
            noise+=weight*vec2<f32>(envelope*cos(angle),envelope*sin(angle));
        }
        sum+=noise;
    }
    // 6 * compute_{2d,3d}_gabor_standard_deviation() (binary32 host constants).
    let normalization=select(6.0,bitcast<f32>(0x40a173beu),three);
    svm_optional_store(s,svm_byte(node+N_TexGabor_value_offset),(sum.y/normalization)*0.5+0.5);
    svm_optional_store(s,svm_byte(node+N_TexGabor_phase_offset),(atan2(sum.y,sum.x)+3.1415927)/6.2831855);
    svm_optional_store(s,svm_byte(node+N_TexGabor_intensity_offset),sqrt(sum.x*sum.x+sum.y*sum.y)/normalization);
}
//#endif
//#if SVM_NODE_WAVELENGTH
// wavelength.h and math_util.h svm_math_wavelength_color_xyz with the
// tables.h cie_color_match rows as constants (no private array).
fn svmn_cie(i:u32)->vec3<f32>{
    switch(i){
        case 0u:{return vec3<f32>(0.00139999995008111,0.0,0.006500000134110451);}
        case 1u:{return vec3<f32>(0.002199999988079071,9.999999747378752e-05,0.010499999858438969);}
        case 2u:{return vec3<f32>(0.00419999985024333,9.999999747378752e-05,0.020099999383091927);}
        case 3u:{return vec3<f32>(0.007600000128149986,0.00019999999494757503,0.03620000183582306);}
        case 4u:{return vec3<f32>(0.014299999922513962,0.00039999998989515007,0.06790000200271606);}
        case 5u:{return vec3<f32>(0.02319999970495701,0.0006000000284984708,0.11020000278949738);}
        case 6u:{return vec3<f32>(0.04349999874830246,0.0012000000569969416,0.20739999413490295);}
        case 7u:{return vec3<f32>(0.07760000228881836,0.002199999988079071,0.37130001187324524);}
        case 8u:{return vec3<f32>(0.13439999520778656,0.004000000189989805,0.6456000208854675);}
        case 9u:{return vec3<f32>(0.21480000019073486,0.007300000172108412,1.0391000509262085);}
        case 10u:{return vec3<f32>(0.2838999927043915,0.011599999852478504,1.385599970817566);}
        case 11u:{return vec3<f32>(0.32850000262260437,0.01679999940097332,1.6230000257492065);}
        case 12u:{return vec3<f32>(0.3483000099658966,0.023000000044703484,1.7470999956130981);}
        case 13u:{return vec3<f32>(0.3481000065803528,0.02979999966919422,1.7826000452041626);}
        case 14u:{return vec3<f32>(0.3361999988555908,0.03799999877810478,1.7720999717712402);}
        case 15u:{return vec3<f32>(0.31869998574256897,0.04800000041723251,1.7440999746322632);}
        case 16u:{return vec3<f32>(0.290800005197525,0.05999999865889549,1.6691999435424805);}
        case 17u:{return vec3<f32>(0.25110000371932983,0.0738999992609024,1.5281000137329102);}
        case 18u:{return vec3<f32>(0.19539999961853027,0.09099999815225601,1.287600040435791);}
        case 19u:{return vec3<f32>(0.1421000063419342,0.11259999871253967,1.0419000387191772);}
        case 20u:{return vec3<f32>(0.09560000151395798,0.13899999856948853,0.8130000233650208);}
        case 21u:{return vec3<f32>(0.057999998331069946,0.16930000483989716,0.6161999702453613);}
        case 22u:{return vec3<f32>(0.03200000151991844,0.20800000429153442,0.4652000069618225);}
        case 23u:{return vec3<f32>(0.014700000174343586,0.25859999656677246,0.353300005197525);}
        case 24u:{return vec3<f32>(0.004900000058114529,0.3230000138282776,0.2720000147819519);}
        case 25u:{return vec3<f32>(0.002400000113993883,0.4072999954223633,0.21230000257492065);}
        case 26u:{return vec3<f32>(0.00930000003427267,0.503000020980835,0.1581999957561493);}
        case 27u:{return vec3<f32>(0.029100000858306885,0.6082000136375427,0.11169999837875366);}
        case 28u:{return vec3<f32>(0.0632999986410141,0.7099999785423279,0.07819999754428864);}
        case 29u:{return vec3<f32>(0.1096000000834465,0.7932000160217285,0.05730000138282776);}
        case 30u:{return vec3<f32>(0.1655000001192093,0.8619999885559082,0.0421999990940094);}
        case 31u:{return vec3<f32>(0.2257000058889389,0.914900004863739,0.02979999966919422);}
        case 32u:{return vec3<f32>(0.2903999984264374,0.9539999961853027,0.0203000009059906);}
        case 33u:{return vec3<f32>(0.3596999943256378,0.9803000092506409,0.013399999588727951);}
        case 34u:{return vec3<f32>(0.4334000051021576,0.9950000047683716,0.008700000122189522);}
        case 35u:{return vec3<f32>(0.5120999813079834,1.0,0.00570000009611249);}
        case 36u:{return vec3<f32>(0.5945000052452087,0.9950000047683716,0.0038999998942017555);}
        case 37u:{return vec3<f32>(0.6783999800682068,0.978600025177002,0.0027000000700354576);}
        case 38u:{return vec3<f32>(0.7620999813079834,0.9520000219345093,0.002099999925121665);}
        case 39u:{return vec3<f32>(0.8424999713897705,0.9154000282287598,0.0017999999690800905);}
        case 40u:{return vec3<f32>(0.9162999987602234,0.8700000047683716,0.0017000000225380063);}
        case 41u:{return vec3<f32>(0.978600025177002,0.8162999749183655,0.00139999995008111);}
        case 42u:{return vec3<f32>(1.0262999534606934,0.7570000290870667,0.0010999999940395355);}
        case 43u:{return vec3<f32>(1.0566999912261963,0.6948999762535095,0.0010000000474974513);}
        case 44u:{return vec3<f32>(1.0621999502182007,0.6309999823570251,0.0007999999797903001);}
        case 45u:{return vec3<f32>(1.0456000566482544,0.5667999982833862,0.0006000000284984708);}
        case 46u:{return vec3<f32>(1.0025999546051025,0.503000020980835,0.0003000000142492354);}
        case 47u:{return vec3<f32>(0.9383999705314636,0.44119998812675476,0.00019999999494757503);}
        case 48u:{return vec3<f32>(0.8543999791145325,0.38100001215934753,0.00019999999494757503);}
        case 49u:{return vec3<f32>(0.7513999938964844,0.32100000977516174,9.999999747378752e-05);}
        case 50u:{return vec3<f32>(0.6424000263214111,0.26499998569488525,0.0);}
        case 51u:{return vec3<f32>(0.5418999791145325,0.21699999272823334,0.0);}
        case 52u:{return vec3<f32>(0.4478999972343445,0.17499999701976776,0.0);}
        case 53u:{return vec3<f32>(0.36079999804496765,0.13819999992847443,0.0);}
        case 54u:{return vec3<f32>(0.28349998593330383,0.10700000077486038,0.0);}
        case 55u:{return vec3<f32>(0.21870000660419464,0.08160000294446945,0.0);}
        case 56u:{return vec3<f32>(0.164900004863739,0.061000000685453415,0.0);}
        case 57u:{return vec3<f32>(0.12120000272989273,0.044599998742341995,0.0);}
        case 58u:{return vec3<f32>(0.08739999681711197,0.03200000151991844,0.0);}
        case 59u:{return vec3<f32>(0.06360000371932983,0.02319999970495701,0.0);}
        case 60u:{return vec3<f32>(0.046799998730421066,0.017000000923871994,0.0);}
        case 61u:{return vec3<f32>(0.03290000185370445,0.011900000274181366,0.0);}
        case 62u:{return vec3<f32>(0.022700000554323196,0.008200000040233135,0.0);}
        case 63u:{return vec3<f32>(0.015799999237060547,0.00570000009611249,0.0);}
        case 64u:{return vec3<f32>(0.01140000019222498,0.004100000020116568,0.0);}
        case 65u:{return vec3<f32>(0.008100000210106373,0.002899999963119626,0.0);}
        case 66u:{return vec3<f32>(0.005799999926239252,0.002099999925121665,0.0);}
        case 67u:{return vec3<f32>(0.004100000020116568,0.001500000013038516,0.0);}
        case 68u:{return vec3<f32>(0.002899999963119626,0.0010000000474974513,0.0);}
        case 69u:{return vec3<f32>(0.0020000000949949026,0.000699999975040555,0.0);}
        case 70u:{return vec3<f32>(0.00139999995008111,0.0005000000237487257,0.0);}
        case 71u:{return vec3<f32>(0.0010000000474974513,0.00039999998989515007,0.0);}
        case 72u:{return vec3<f32>(0.000699999975040555,0.00019999999494757503,0.0);}
        case 73u:{return vec3<f32>(0.0005000000237487257,0.00019999999494757503,0.0);}
        case 74u:{return vec3<f32>(0.0003000000142492354,9.999999747378752e-05,0.0);}
        case 75u:{return vec3<f32>(0.00019999999494757503,9.999999747378752e-05,0.0);}
        case 76u:{return vec3<f32>(0.00019999999494757503,9.999999747378752e-05,0.0);}
        case 77u:{return vec3<f32>(9.999999747378752e-05,0.0,0.0);}
        case 78u:{return vec3<f32>(9.999999747378752e-05,0.0,0.0);}
        case 79u:{return vec3<f32>(9.999999747378752e-05,0.0,0.0);}
        default:{return vec3<f32>(0.0,0.0,0.0);}
    }
}
fn svm_wavelength(s:ptr<function,SvmState>,node:u32){
    let lambda=svm_input(s,node+N_Wavelength_wavelength);if((*s).error!=0u){return;}
    var ii=(lambda-380.0)*0.2;
    // float_to_int truncates toward zero (ii in (-1,0) extrapolates from row 0, as on
    // the host); NaN and out-of-range values give the host's zero colour.
    var xyz=vec3<f32>(0);
    if(ii==ii&&ii>-1.0&&ii<80.0){
        let i=u32(i32(ii));ii-=f32(i);var c=array<vec3<f32>,2>();
        for(var k=0u;k<2u;k++){c[k]=svmn_cie(i+k);}
        xyz=rounded_add3(c[0],ii*(c[1]-c[0]));
    }
    let film=p(6u);
    var rgb=vec3<f32>(svmn_dot(heap_vec3(film+SVMN_D_film_xyz_to_r),xyz),svmn_dot(heap_vec3(film+SVMN_D_film_xyz_to_g),xyz),svmn_dot(heap_vec3(film+SVMN_D_film_xyz_to_b),xyz));
    // 1.0f/2.52f folded in binary32 by the host compiler.
    rgb*=bitcast<f32>(0x3ecb2cb3u);
    svm_store3(s,svm_byte(node+N_Wavelength_color_offset),max(rgb,vec3<f32>(0)));
}
//#endif
//#if SVM_NODE_WIREFRAME
// wireframe.h. Triangle corners come from the same native vertex tables as the
// shader-data setup (motion triangles included), object space corners use the
// shading point's object or motion transform. Background and volume
// evaluations have no primitive (0), as on the host.
fn svm_wireframe(s:ptr<function,SvmState>,node:u32){
    let size=svm_input(s,node+N_Wireframe_in_size);if((*s).error!=0u){return;}
    let g=(*s).geometry;var f=0.0;
    if(!(*s).volume&&g.prim!=NONE&&native_triangle_kind(g.primitive_type)){
        // differential_from_compact(Ng, dP): make_orthonormals frame scaled by dP.
        let tangent=surface_orthogonal(g.Ng);let dx=tangent*g.dP;let dy=cross(g.Ng,tangent)*g.dP;
        var position=g.P;let bump=svm_byte(node+N_Wireframe_bump_offset);let width=bitcast<f32>(load_word(node+N_Wireframe_bump_filter_width));
        if(bump==NODE_BUMP_OFFSET_DX){position+=dx*width;}else if(bump==NODE_BUMP_OFFSET_DY){position+=dy*width;}
        let vertices=native_triangle_vertices(g.object_id,g.prim,g.primitive_type,g.time);
        if(vertices.error!=0u){svm_error(s,16u);return;}
        var corners=array<vec3<f32>,3>(vertices.a,vertices.b,vertices.c);
        if((g.object_flag&SD_OBJECT_TRANSFORM_APPLIED)==0u){for(var k=0u;k<3u;k++){corners[k]=surface_object_point(g,corners[k],false);}}
        var pixelwidth=1.0;
        if(svm_byte(node+N_Wireframe_use_pixel_size)!=0u){
            let x=dx-svmn_dot(dx,g.wi)*g.wi;let y=dy-svmn_dot(dy,g.wi)*g.wi;
            pixelwidth=(sqrt(svmn_dot(x,x))+sqrt(svmn_dot(y,y)))*0.5;
        }
        pixelwidth*=0.5*size;pixelwidth*=pixelwidth;
        for(var i=0u;i<3u;i++){
            let edge=corners[i]-corners[select(2u,i-1u,i>0u)];let crs=rounded_cross(edge,position-corners[i]);
            if(rounded_dot(crs,crs)<rounded_dot(edge,edge)*pixelwidth){f=1.0;break;}
        }
    }
    svm_optional_store(s,svm_byte(node+N_Wireframe_out_fac_offset),f);
}
//#endif
